// Cart-abandonment recovery blast (admin-only) — idempotent + batched.
//
// KINEO-ABANDON-RECOVERY-2026-07-08 — email everyone who clicked a checkout
// button (*_checkout_clicked event) but never paid, offering 20% off any plan
// with code KINEO20 (auto-applied via the link). Attacks the #1 leak: abandonment
// at the decision moment. Idempotent via profiles.abandon_emailed; only flags on a
// successful send; paces sends under Resend's free 100/day cap.
//
// MODES (admin- or cron-gated, GET):
//   (no params)            → DRY RUN: who would receive it (count + sample).
//   ?confirm=SEND&limit=N  → send to the next N unflagged recipients (default 90),
//                            pacing each send, marking the flag on success.
//
// KINEO-REBASE-2026-07-10 — ROBÔ NA ROTINA: besides the admin cookie, the
// route now accepts `Authorization: Bearer ${CRON_SECRET}` so the daily
// send-reminders cron (10:00 UTC, vercel.json) can call it server-to-server
// every day. Idempotency is already built in (profiles.abandon_emailed,
// flagged on SUCCESSFUL send only), so a daily call only ever emails NEW
// abandoners — nobody gets the offer twice.
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createClient as createAdminClient } from '@supabase/supabase-js'
import { emailFooterHtml, unsubscribeHeaders } from '@/lib/emailSuppression'

export const maxDuration = 300
export const dynamic = 'force-dynamic'

const ADMIN_EMAILS = new Set([
  'josephsskaf@gmail.com',
  'josephskaf@gmail.com',
  'joseph-test@shortsforgeai.com',
])

// hello@ = prospecção/resgate de leads (support@ is reserved for support).
const FROM_EMAIL = 'Joseph at Kineo <hello@usekineo.com>'
const REPLY_TO = 'hello@usekineo.com'
// KINEO-INTRO-MONTH-2026-07-13 — oferta trocada: 20% off (KINEO20) → 1º mês
// do Starter por $4.90. Desconto mais fundo (50% vs 20%) E recorrente por
// design: quem resgata vira assinatura, não cupom avulso. O link vai direto
// pro checkout com ?intro=1 (o servidor aplica o cupom e valida 1-por-conta).
const SUBJECT = 'Still thinking it over? First month $4.90'

// The checkout-click events fired across pricing, homepage, and the watermark moment.
const CHECKOUT_EVENTS = [
  'starter_checkout_clicked',
  'basic_checkout_clicked',
  'pro_checkout_clicked',
  'starter_pack_checkout_clicked',
]

// Ramon already bought — never email him a recovery offer.
const RAMON = 'ramonwilliamson@gmail.com'

// Disposable / throwaway inbox domains — sending to these hurts sender reputation.
const DISPOSABLE_DOMAINS = new Set([
  'yopmail.com', 'gmeenramy.com', 'kinws.com', 'doefy.com', 'x-box.in',
  'mailinator.com', 'guerrillamail.com', 'sharklasers.com', 'tempmail.com',
  '10minutemail.com', 'trashmail.com', 'getnada.com', 'dispostable.com',
  'maildrop.cc', 'mohmal.com', 'temp-mail.org', 'fakeinbox.com',
])

function isInternal(email: string): boolean {
  if (email === RAMON) return true
  if (ADMIN_EMAILS.has(email)) return true
  if (email.startsWith('josephsskaf') || email.startsWith('josephskaf')) return true
  if (email.startsWith('joseph+') || email.startsWith('joseph-')) return true
  if (email === 'victoriaskaf96@gmail.com') return true
  const dom = email.split('@')[1] ?? ''
  if (dom === 'shortsforgeai.com' || dom === 'usekineo.com' || dom === 'theresanaiforthat.com') return true
  return false
}

const PAID_PLANS = new Set(['starter', 'starter_trial', 'basic', 'basic_trial', 'pro', 'pro_trial'])

function isValidExternalEmail(email: string): boolean {
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return false
  if (email.includes('example.com') || email.startsWith('test@') || email.startsWith('smoketest')) return false
  const dom = email.split('@')[1] ?? ''
  if (DISPOSABLE_DOMAINS.has(dom)) return false
  if (isInternal(email)) return false
  return true
}

// KINEO-CHECKOUT-TRIAGE-2026-07-25 — these two CTAs used to point straight at
// https://usekineo.com/api/stripe/checkout?tier=...&intro=1. Corporate mail
// scanners (Outlook Safe Links, Proofpoint, Mimecast) GET every link in an
// email before the human ever sees it, so each send minted Stripe Sessions
// nobody clicked. Both now land on /pricing, which is a plain page.
//
// Intent is preserved: /pricing reads ?promo= and ?intent_campaign= and
// forwards them to the checkout route, and its handleBuy() already appends
// &intro=1 automatically for monthly starter/basic — the exact half-price
// first month this email promises. NOTE: /pricing does NOT currently read
// ?tier=, so that param is carried for attribution only; the reader still
// picks the plan card themselves.
//
// KINEO-UNSUBSCRIBE-2026-07-26 — recebe userId para montar o rodapé com o link
// de descadastro (CAN-SPAM §7704(a)(3)/(a)(5)).
function emailHtml(userId: string): string {
  return `
<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:0 auto;color:#1e293b;line-height:1.6">
  <p>Hey — Joseph here, founder of <b>Kineo</b> 🎬</p>
  <p>I noticed you got as far as checkout but didn't finish. No pressure — but if price was the thing holding you back, let me help.</p>
  <p style="font-size:18px;margin:18px 0"><b>Your first month for $4.90</b> — half price. 25 credits, watermark-free videos, cancel anytime.</p>
  <p style="margin:26px 0">
    <a href="https://usekineo.com/pricing?tier=starter&intent_campaign=abandon_recovery" style="background:#2997ff;color:#ffffff;padding:13px 24px;border-radius:10px;text-decoration:none;font-weight:bold">Start for $4.90 &rarr;</a>
  </p>
  <p style="color:#475569;font-size:14px">Renews at $9.90/mo after the first month — cancel anytime with two clicks · 7-day money-back guarantee. Want more power? The Creator plan (150 credits + 1 Hollywood film/month) is also half off: <a href="https://usekineo.com/pricing?tier=basic&intent_campaign=abandon_recovery" style="color:#2997ff">first month $9.90</a>.</p>
  <p>If something else held you back — a feature or a question — just reply to this email. It comes straight to me.</p>
  <p>— Joseph, founder<br/>Kineo · https://usekineo.com</p>
</div>
${emailFooterHtml(userId)}`
}

function adminClient() {
  return createAdminClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL as string,
    process.env.SUPABASE_SERVICE_ROLE_KEY as string,
    { auth: { persistSession: false, autoRefreshToken: false } },
  )
}

export async function GET(req: NextRequest) {
  try {
    // KINEO-REBASE-2026-07-10 — cron auth path: the daily send-reminders cron
    // calls this route with the CRON_SECRET bearer (no admin cookie on a
    // server-to-server hop). Only honored when CRON_SECRET is actually set.
    const cronSecret = process.env.CRON_SECRET
    const isCronCall =
      !!cronSecret && req.headers.get('authorization') === `Bearer ${cronSecret}`

    if (!isCronCall) {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      const email = (user?.email ?? '').toLowerCase()
      if (!user || !ADMIN_EMAILS.has(email)) {
        return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
      }
    }
    if (!process.env.RESEND_API_KEY) {
      return NextResponse.json({ error: 'RESEND_API_KEY not configured' }, { status: 500 })
    }
    if (!process.env.SUPABASE_SERVICE_ROLE_KEY || !process.env.NEXT_PUBLIC_SUPABASE_URL) {
      return NextResponse.json({ error: 'Service credentials not configured' }, { status: 500 })
    }

    const admin = adminClient()

    // 1) user_ids that fired a checkout-click event (the universe of abandoners).
    const { data: evRows, error: evErr } = await admin
      .from('events')
      .select('user_id')
      .in('name', CHECKOUT_EVENTS)
      .not('user_id', 'is', null)
    if (evErr) {
      return NextResponse.json({ error: `events query failed: ${evErr.message}` }, { status: 500 })
    }
    const clickerIds = Array.from(
      new Set((evRows ?? []).map((e) => (e as { user_id: string | null }).user_id).filter(Boolean) as string[]),
    )
    if (clickerIds.length === 0) {
      return NextResponse.json({ mode: 'DRY_RUN', remaining_unemailed: 0, note: 'no checkout-click events yet' })
    }

    // 2) those clickers' profiles: unpaid + not yet recovery-emailed.
    const { data: rows, error } = await admin
      .from('profiles')
      .select('id, email, plan, is_pro, has_paid')
      .in('id', clickerIds)
      .eq('abandon_emailed', false)
      // KINEO-UNSUBSCRIBE-2026-07-26 — quem pediu para sair NUNCA entra em coorte.
      .eq('email_opted_out', false)
    if (error) {
      return NextResponse.json({ error: `profiles query failed: ${error.message}` }, { status: 500 })
    }

    type Row = {
      id: string
      email: string | null
      plan: string | null
      is_pro: boolean | null
      has_paid: boolean | null
    }

    const seen = new Set<string>()
    const recipients = (rows ?? [])
      .map((r) => {
        const row = r as Row
        return { id: row.id, email: (row.email ?? '').trim().toLowerCase(), plan: (row.plan ?? '').toLowerCase(), is_pro: !!row.is_pro, has_paid: !!row.has_paid }
      })
      // free / unpaid only — never chase someone who already pays
      .filter((r) => !r.has_paid && !r.is_pro && !PAID_PLANS.has(r.plan))
      // valid external, non-disposable, non-internal, non-Ramon
      .filter((r) => isValidExternalEmail(r.email))
      // de-dupe by email
      .filter((r) => (seen.has(r.email) ? false : (seen.add(r.email), true)))

    const confirm = req.nextUrl.searchParams.get('confirm') === 'SEND'
    const limitParam = Number(req.nextUrl.searchParams.get('limit'))
    const batchSize = Number.isFinite(limitParam) && limitParam > 0 ? Math.min(limitParam, 1000) : 90

    if (!confirm) {
      return NextResponse.json({
        mode: 'DRY_RUN',
        cohort: 'clicked checkout, unpaid, non-disposable, not yet recovery-emailed',
        clickers_total: clickerIds.length,
        remaining_unemailed: recipients.length,
        next_batch_size: Math.min(batchSize, recipients.length),
        sample: recipients.slice(0, 8).map((r) => r.email),
        subject: SUBJECT,
        from: FROM_EMAIL,
        hint: 'Append &confirm=SEND (optionally &limit=N) to send the next batch.',
      })
    }

    const batch = recipients.slice(0, batchSize)
    let sent = 0
    let failed = 0
    for (const r of batch) {
      try {
        const res = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            from: FROM_EMAIL,
            to: [r.email],
            reply_to: REPLY_TO,
            subject: SUBJECT,
            html: emailHtml(r.id),
            headers: unsubscribeHeaders(r.id),
          }),
        })
        if (res.ok) {
          sent += 1
          // Flag on success only — a failed send stays pending for the next batch.
          await admin.from('profiles').update({ abandon_emailed: true }).eq('id', r.id)
        } else {
          failed += 1
          console.error(`[abandon-recovery] resend failed for ${r.email}:`, await res.text())
        }
      } catch (e) {
        failed += 1
        console.error(`[abandon-recovery] send threw for ${r.email}:`, e instanceof Error ? e.message : String(e))
      }
      await new Promise((res) => setTimeout(res, 700))
    }

    console.log(`[abandon-recovery] batch done: sent=${sent} failed=${failed}`)
    return NextResponse.json({ mode: 'SENT', sent, failed, batch_size: batch.length })
  } catch (err) {
    console.error('[abandon-recovery] unexpected:', err)
    return NextResponse.json({ error: 'Unexpected error' }, { status: 500 })
  }
}
