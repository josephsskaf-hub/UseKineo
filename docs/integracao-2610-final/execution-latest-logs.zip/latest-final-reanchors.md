# Auditoria final da composição sobre mainFFE — snapshot 8461529a1

**FATO CONFIRMADO — somente leitura:** commit auditado `8461529a1bbbc53b46e8f31c10bd489d3b6ea524`, filho de `2111b1668c6f57359e3f0c17e1491a7ed4c19ade`. A integração anterior `917d1f8728b0d73d6ffb518e2e16051fbd3d9f9a`, a main atual `ffe52785608c868cdc9215ec878f7de6f841a2e6` e as quatro levas permanecem ancestrais. Evidência completa desta revisão: `latest-final-audit.json`.

**FATO CONFIRMADO:** dos **23 caminhos** recebidos da mainFFE, **20 blobs** são idênticos à FFE. As três diferenças são exclusivamente os guardiões Home remodelada, Kids venda e Em Alta. Todos os arquivos de produto e mídia recebidos permanecem byte a byte FFE. O delta 917 → 846 contém somente esses 23 caminhos e o selo corrente; nenhum caminho inesperado apareceu. O selo inventaria **965 arquivos / 964 hashes**. Fontes: objetos Git e inventários registrados em `latest-final-audit.json`, revisão de 26/10/2026 em America/Sao_Paulo.

## Reancoragem estrita de Em Alta

| Classificação | Prova mantida ou acrescentada | Referência no commit 846 |
|---|---|---|
| **FATO CONFIRMADO — A/B/C** | Os controles brutos de catálogo, arquivos de prévia/pôster, motor/duração/formato, prompts, ausência dos nomes vedados e preenchimento da UI foram preservados integralmente da FFE. Continuam exigindo que `applyTrend` não gere nem chame a API. A comparação textual independente dos blocos A/B/C foi idêntica. | `scripts/test-em-alta-2610.mjs:17`, `:32`, `:33`. |
| **FATO CONFIRMADO — D1** | O escopo próprio da entrega de UI é conferido entre as fontes imutáveis `237b14fb186655e448e9d2e5e80b5b904a8e9863` e `f9216bf8728cb86adac67c59c9b8ca47c06521f9`. Não há caminho `app/api/` nesse delta. Assim o teste não atribui à UI as APIs das outras quatro levas aprovadas. | `scripts/test-em-alta-2610.mjs:42`, `:48`, `:49`. |
| **FATO CONFIRMADO — D2, inventário completo** | O conjunto atual de APIs, medido contra mainFFE e incluindo arquivos não rastreados, deve ser exatamente o delta aprovado main237 → integração917. A revisão independente encontrou **28 caminhos** nos dois conjuntos, sem falta ou sobra. | `scripts/test-em-alta-2610.mjs:51`, `:65`, `:69`, `:84`. |
| **FATO CONFIRMADO — D2, APIs preexistentes** | Uma API que já existia em main237 deve passar pela projeção da fonte atual integralmente selada e chegar exatamente ao blob237. Fonte desconhecida não é projetada. A revisão independente também verificou que todos os **28 blobs brutos** do conjunto atual são iguais aos aprovados em917; a conclusão não depende apenas da projeção. | `scripts/test-em-alta-2610.mjs:74`, `:76`; lista em `latest-final-audit.json`, campo `emAltaBoundary.sources`. |
| **FATO CONFIRMADO — D2, APIs novas** | Uma API ausente na main237 não pode inventar predecessor: deve ser bruta e exatamente o blob aprovado de917. A leitura histórica usa `git cat-file blob` e conserva ausência como ausência. | `scripts/test-em-alta-2610.mjs:58`, `:78`, `:79`. |
| **FATO CONFIRMADO — D3 e D4** | O conjunto completo de APIs é conferido também em CRLF; a projeção histórica deve ser idempotente para cada caminho aprovado. | `scripts/test-em-alta-2610.mjs:85`, `:86`, `:87`. |
| **FATO CONFIRMADO — M1 preservado** | O mutante original que remove o preenchimento da ideia em `applyTrend` foi mantido byte a byte da FFE. | `scripts/test-em-alta-2610.mjs:99`, `:100`. |
| **FATO CONFIRMADO — M2 e M3** | Um acréscimo desconhecido em `app/api/events/route.ts` continua vermelho; o mesmo vale para uma API nova que não existia na main237. A existência dos alvos é exigida e a alteração não recebe um selo novo. | `scripts/test-em-alta-2610.mjs:91`, `:92`, `:94`, `:95`. |

**TESTADO LOCALMENTE — execução dirigida registrada:** o log real `latest-emalta-846.log` termina em **23 ok, 0 falha(s)**; a execução do agente principal retornou código0 no commit846. O arquivo foi gravado em `2026-10-27T01:34:56.497Z` = 26/10 às22:34:56 em São Paulo. Esta auditoria leu o log e não repetiu o teste. O `latest-smoke/` antigo pertence à rodada diagnóstica2111 e não é a evidência desta aprovação.

## Outras composições e preservação

| Classificação | Resultado da revisão |
|---|---|
| **FATO CONFIRMADO — Home** | A leitura afiliado do pai917 continua; `semHomeGatoCarro2610` sai antes de HomeRemodela nas duas provas, normal e CRLF. Referências: `scripts/test-home-remodela-2010.mjs:29`, `:36`, `:38`, `:227`, `:230`. |
| **FATO CONFIRMADO — Kids** | Continuam afiliado/Compra Avulsa; `semCronOrigem2610` sai antes do desfaz Kids na prova histórica. Referências: `scripts/test-kids-venda-2010.mjs:21`, `:23`, `:30`, `:37`, `:266`. |
| **FATO CONFIRMADO — eventos** | `app/api/events/route.ts` é o mesmo blob do pai917: **190 eventos server-only**, nenhum perdido. |
| **FATO CONFIRMADO — Perfeito/Privacidade/MCP** | Todos os arquivos de scope/addedSources Perfeito, seu manifesto e os arquivos protegidos de Privacidade/MCP comparados permanecem idênticos ao pai917. A relação exata está em `latest-final-audit.json`, campo `preservedThreeLayers`; nenhum resultado divergente foi encontrado. |
| **FATO CONFIRMADO — testes e selo** | MainFFE: **1.037 arquivos**; integração846: **1.062**. Entraram os dois testes da main, Cron Origem e Em Alta; nenhum teste anterior foi removido e nenhum teste da FFE falta. Esses são inventários, não resultados da suíte. Selo965/964; árvore limpa na leitura. |

**QUESTÃO PENDENTE — execução completa nova:** `integration-latest/manifest.json` registra commit846, início `2026-10-27T01:29:22.507Z` = 26/10 às22:29:22 em São Paulo, **1.062 arquivos** e um trabalhador. A suíte ainda está em andamento nesta revisão. A aprovação dirigida de Em Alta e a auditoria de blobs não substituem o novo fechamento completo mainFFE × integração846.

**FATO CONFIRMADO — limites da revisão:** não executei testes, build, deploy, SQL ou alterações na worktree. Apenas li fontes/evidências e gravei estes dois insumos temporários. Não foi encontrada perda concreta de produto, evento ou teste, nem relaxamento dos controles A/B/C/M1; D2/D3/D4/M2/M3 acrescentam controles sobre a composição aprovada e suas mutações desconhecidas.
