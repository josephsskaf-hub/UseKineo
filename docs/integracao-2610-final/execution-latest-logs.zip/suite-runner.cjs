const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const root = path.resolve(process.argv[2]);
const out = path.resolve(process.argv[3]);
const limit = Number(process.argv[4] || 2);
fs.mkdirSync(out, {recursive:true});
fs.mkdirSync(path.join(out,'logs'), {recursive:true});
const temp = path.join(out,'tmp'); fs.mkdirSync(temp, {recursive:true});
const env = {};
for (const key of Object.keys(process.env)) if (/^(PATH|PATHEXT|SYSTEMROOT|WINDIR|COMSPEC|USERPROFILE|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|ALLUSERSPROFILE|HOMEDRIVE|HOMEPATH|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE|OS)$/i.test(key)) env[key]=process.env[key];
env.TMP=temp; env.TEMP=temp; env.GIT_TERMINAL_PROMPT='0'; env.GIT_ALLOW_PROTOCOL='file';
const git = (...args) => cp.execFileSync('git',args,{cwd:root,encoding:'utf8',env,windowsHide:true,maxBuffer:16*1024*1024}).trim();
const head = git('rev-parse','HEAD');
const files = git('ls-files','-z').split('\0').filter(p=>/^scripts\/test-[^/]*\.mjs$|^docs\/(?:.*\/)?test[^/]*\.mjs$|^tests\/[^/]*\.test\.mjs$/.test(p)).sort();
const manifest = {root,head,started:new Date().toISOString(),node:process.version,concurrency:limit,timeoutMs:1200000,files,envPolicy:'allowlist of Windows runtime/path variables; no credentials; GIT_ALLOW_PROTOCOL=file; own TEMP/TMP',results:[]};
if(fs.existsSync(path.join(out,'results.json'))){ const previous=JSON.parse(fs.readFileSync(path.join(out,'results.json'),'utf8')); if(previous.head!==head)throw Error('Resume HEAD differs'); manifest.started=previous.started; manifest.results=previous.results; manifest.resumed=new Date().toISOString(); }
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2));
const writeResults = () => fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(manifest,null,2));
const exclusive=[], parallel=[];
for (const file of files) {
  if(manifest.results.some(r=>r.file===file&&!r.timedOut))continue;
  const source=fs.readFileSync(path.join(root,file),'utf8');
  (/writeFile|mkdir|\brmSync|\bunlink|rmdir/.test(source)?exclusive:parallel).push(file);
}
console.log(JSON.stringify({event:'start',root,head,total:files.length,parallel:parallel.length,exclusive:exclusive.length}));
async function run(file, attempt=1) {
  const start=Date.now(); const logName=file.replaceAll('/','__')+(attempt>1?'.retry':'')+'.log';
  const output=fs.createWriteStream(path.join(out,'logs',logName));
  const child=cp.spawn(process.execPath,[file],{cwd:root,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
  child.stdout.pipe(output,{end:false}); child.stderr.pipe(output,{end:false});
  let timedOut=false, spawnError;
  const timer=setTimeout(()=>{timedOut=true; cp.spawn('taskkill',['/PID',String(child.pid),'/T','/F'],{windowsHide:true,stdio:'ignore'});},1200000);
  child.on('error',e=>{spawnError=e.message});
  const code = await new Promise(resolve=>child.on('close',resolve));
  clearTimeout(timer); await new Promise(resolve=>output.end(resolve));
  const result={file,attempt,code,signal:child.signalCode,timedOut,error:spawnError,durationMs:Date.now()-start,log:path.join(out,'logs',logName)};
  manifest.results.push(result);writeResults();
  if(code!==0||timedOut)console.log(JSON.stringify({event:'fail',...result}));
  if(manifest.results.length%100===0)console.log(JSON.stringify({event:'progress',done:manifest.results.length,total:files.length,failed:manifest.results.filter(r=>r.code!==0).length}));
  return result;
}
(async()=>{
 let next=0; const active=new Set(); let lastCap;
 while(next<parallel.length || active.size){
   const control=path.join(out,'workers.json');
   const cap=Math.max(1,Math.min(4,fs.existsSync(control)?Number(JSON.parse(fs.readFileSync(control,'utf8')).readOnlyWorkers):limit));
   if(cap!==lastCap){manifest.workerCaps??=[];manifest.workerCaps.push({at:new Date().toISOString(),cap});lastCap=cap;console.log(JSON.stringify({event:'read-only-workers',cap}));}
   while(next<parallel.length && active.size<cap){const file=parallel[next++];const job=run(file).finally(()=>active.delete(job));active.add(job);}
   if(active.size)await Promise.race(active);
 }
 console.log(JSON.stringify({event:'parallel-finished',done:manifest.results.length}));
 for(const file of exclusive)await run(file);
 const timeouts=manifest.results.filter(r=>r.timedOut).map(r=>r.file);
 for(const file of timeouts)await run(file,2);
 const tscLog=fs.createWriteStream(path.join(out,'tsc.log'));
 const tscStart=Date.now(); const tsc=cp.spawn('cmd.exe',['/d','/s','/c','npx tsc --noEmit'],{cwd:root,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
 tsc.stdout.pipe(tscLog,{end:false});tsc.stderr.pipe(tscLog,{end:false});
 const tscCode=await new Promise(resolve=>tsc.on('close',resolve)); await new Promise(resolve=>tscLog.end(resolve));
 manifest.tsc={code:tscCode,durationMs:Date.now()-tscStart,log:path.join(out,'tsc.log')};
 const realLog=fs.createWriteStream(path.join(out,'tsc-real.log'));
 const realStart=Date.now(); const realTsc=cp.spawn(process.execPath,[path.join(root,'node_modules/typescript/bin/tsc'),'--noEmit'],{cwd:root,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
 realTsc.stdout.pipe(realLog,{end:false});realTsc.stderr.pipe(realLog,{end:false});
 const realCode=await new Promise(resolve=>realTsc.on('close',resolve));await new Promise(resolve=>realLog.end(resolve));
 manifest.realTsc={code:realCode,durationMs:Date.now()-realStart,log:path.join(out,'tsc-real.log')};
 manifest.ended=new Date().toISOString();manifest.finalStatus=git('status','--porcelain');
 manifest.failures=files.filter(file=>manifest.results.filter(r=>r.file===file).at(-1)?.code!==0);writeResults();
 console.log(JSON.stringify({event:'finished',total:files.length,failures:manifest.failures,tsc:manifest.tsc,finalStatus:manifest.finalStatus}));
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
